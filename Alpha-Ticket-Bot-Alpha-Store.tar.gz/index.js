console.log("\n░█████╗░██╗░░░░░██████╗░██╗░░██╗░█████╗░\n██╔══██╗██║░░░░░██╔══██╗██║░░██║██╔══██╗\n███████║██║░░░░░██████╔╝███████║███████║\n██╔══██║██║░░░░░██╔═══╝░██╔══██║██╔══██║\n██║░░██║███████╗██║░░░░░██║░░██║██║░░██║\n╚═╝░░╚═╝╚══════╝╚═╝░░░░░╚═╝░░╚═╝╚═╝░░╚═╝\n\n░██████╗████████╗░█████╗░██████╗░███████╗\n██╔════╝╚══██╔══╝██╔══██╗██╔══██╗██╔════╝\n╚█████╗░░░░██║░░░██║░░██║██████╔╝█████╗░░\n░╚═══██╗░░░██║░░░██║░░██║██╔══██╗██╔══╝░░\n██████╔╝░░░██║░░░╚█████╔╝██║░░██║███████╗\n╚═════╝░░░░╚═╝░░░░╚════╝░╚═╝░░╚═╝╚══════╝");
const {
  Routes,
  REST
} = require("discord.js");
const {
  CustomClient
} = require("./src/utils/index");
const fs = require('fs');
const client = new CustomClient();
const commands = [];
const commandFiles = fs.readdirSync("./src/commands").filter(_0x4f0f96 => _0x4f0f96.endsWith(".js"));
for (const file of commandFiles) {
  const command = require("./src/commands/" + file);
  client.commands.set(command.name, command);
  commands.push(command.data);
}
const interactionsFiles = fs.readdirSync("./src/interactions").filter(_0x5c9212 => _0x5c9212.endsWith(".js"));
for (const file of interactionsFiles) {
  const interaction = require("./src/interactions/" + file);
  client.interactions.set(interaction.name, interaction);
}
const eventsFiles = fs.readdirSync("./src/events").filter(_0xc40823 => _0xc40823.endsWith(".js"));
for (const file of eventsFiles) {
  const event = require("./src/events/" + file);
  client.on(event.name, async (..._0x101f0c) => {
    event.execute(client, ..._0x101f0c);
  });
}
const eventsLangs = fs.readdirSync("./src/locale").filter(_0xb947d9 => _0xb947d9.endsWith(".json"));
for (const file of eventsLangs) {
  const locale = require("./src/locale/" + file);
  client.locale.set(file.split('.')[0], locale);
}
const rest = new REST().setToken(client.config.TOKEN);
client.once("ready", async () => {
  await rest.put(Routes.applicationCommands(client.user.id), {
    'body': commands
  });
  console.log("[32mBot is online! " + client.user.username + "[0m");
  console.log("[34mTicket Bot by Alpha Store Codding[0m");
  console.log("[33mhttps://discord.gg/8aSe3Hg2FE[0m");
});
client.login(client.config.TOKEN);
module.exports = {
  'name': "interactionCreate",
  async 'execute'(_0x41721c, _0x58ccd3) {
    if (_0x58ccd3.isCommand()) {
      const _0x3c1c35 = _0x41721c.commands.get(_0x58ccd3.commandName);
      _0x3c1c35.execute(_0x41721c, _0x58ccd3);
    }
    if (!_0x58ccd3.isAnySelectMenu() && !_0x58ccd3.isButton() && !_0x58ccd3.isModalSubmit()) {
      return;
    }
    const _0x41db9b = _0x41721c.interactions.get(_0x58ccd3.customId.split('*')[0]);
    if (_0x41db9b) {
      _0x41db9b.execute(_0x41721c, _0x58ccd3);
    }
  }
};
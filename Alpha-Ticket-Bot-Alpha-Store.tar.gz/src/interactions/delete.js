module.exports = {
  'name': "delete",
  async 'execute'(_0xb37f2e, _0x3a34f8) {
    const _0x5bc336 = _0xb37f2e.locale.get(_0xb37f2e.config.language);
    _0x3a34f8.reply({
      'content': _0x5bc336["delete"].deleteTimer,
      'ephemeral': true
    });
    setTimeout(() => {
      _0x3a34f8.channel["delete"]();
    }, 5000);
  }
};
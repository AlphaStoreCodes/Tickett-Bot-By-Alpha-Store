const {
  ActionRowBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle
} = require("discord.js");
module.exports = {
  'name': "close",
  async 'execute'(_0x5b7fa2, _0x4bf062) {
    const _0x58cc2e = _0x5b7fa2.locale.get(_0x5b7fa2.config.language);
    await _0x4bf062.deferReply({
      'ephemeral': true
    });
    const _0x14f781 = new EmbedBuilder().setColor("#05131f").setTitle("Confirmation").setDescription(_0x58cc2e.close.confirm);
    const _0x55c6eb = new ButtonBuilder().setCustomId("confirm_yes").setLabel(_0x58cc2e.close.yes).setStyle(ButtonStyle.Secondary);
    const _0x474d42 = new ButtonBuilder().setCustomId("confirm_no").setLabel(_0x58cc2e.close.no).setStyle(ButtonStyle.Secondary);
    const _0x4e797e = new ActionRowBuilder().addComponents(_0x55c6eb, _0x474d42);
    await _0x4bf062.editReply({
      'embeds': [_0x14f781],
      'components': [_0x4e797e],
      'ephemeral': true
    });
  }
};
module.exports = {
  'name': "confirm_no",
  async 'execute'(_0x4087e, _0xa3b5b4) {
    const _0x30b1d0 = _0x4087e.locale.get(_0x4087e.config.language);
    await _0xa3b5b4.deferUpdate();
    await _0xa3b5b4.editReply({
      'content': _0x30b1d0.confirmNo.cancelConfirmation
    });
  }
};
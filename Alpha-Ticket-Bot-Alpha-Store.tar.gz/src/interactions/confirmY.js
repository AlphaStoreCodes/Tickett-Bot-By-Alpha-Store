module.exports = {
  'name': "confirm_yes",
  async 'execute'(_0xcb790, _0x3fa5dd) {
    const _0x1576d5 = _0xcb790.locale.get(_0xcb790.config.language);
    await _0x3fa5dd.deferUpdate();
    await _0x3fa5dd.channel.permissionOverwrites.set([{
      'id': _0x3fa5dd.guild.id,
      'deny': [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages]
    }, {
      'id': _0x3fa5dd.channel.topic,
      'deny': [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages]
    }])["catch"](() => {});
    await _0x3fa5dd.editReply({
      'content': _0x1576d5.confirmYes.closed,
      'embeds': [],
      'components': [],
      'ephemeral': true
    });
    const _0x57aa34 = new EmbedBuilder().setColor("#05131f").setTitle(_0x1576d5.confirmYes.closed);
    await _0x3fa5dd.channel.setName('' + _0x3fa5dd.channel.name.replace('🎫', '🔒'));
    const _0x5b2ec6 = new ButtonBuilder().setCustomId("save").setLabel(_0x1576d5.confirmYes.save).setStyle(ButtonStyle.Secondary);
    const _0xfcb1ba = new ButtonBuilder().setCustomId("delete").setLabel(_0x1576d5.confirmYes["delete"]).setStyle(ButtonStyle.Secondary);
    const _0x5f1779 = new ActionRowBuilder().addComponents(_0x5b2ec6, _0xfcb1ba);
    await _0x3fa5dd.followUp({
      'embeds': [_0x57aa34],
      'components': [_0x5f1779]
    });
    const _0x37c995 = await _0xcb790.db.get("ticket-" + _0x3fa5dd.guild.id + '-' + _0x3fa5dd.channel.topic);
    await _0xcb790.db.set("ticket-" + _0x3fa5dd.guild.id + '-' + _0x3fa5dd.channel.topic, {
      ..._0x37c995,
      'closedBy': _0x3fa5dd.user.id
    });
    const _0x227251 = await generateHtmlPage(_0x3fa5dd.channel);
    const _0x4e8411 = new EmbedBuilder().setTitle(_0x1576d5.confirmYes.ticketClosed).setColor("#05131f").addFields({
      'name': _0x1576d5.confirmYes.openedBy,
      'value': '<@' + _0x3fa5dd.channel.topic + '>',
      'inline': true
    }, {
      'name': _0x1576d5.confirmYes.claimedBy,
      'value': _0x37c995.claimed ? '<@' + _0x37c995.claimed + '>' : _0x1576d5.confirmYes.noOne,
      'inline': true
    }, {
      'name': _0x1576d5.confirmYes.closedBy,
      'value': '<@' + _0x3fa5dd.user.id + '>',
      'inline': true
    }, {
      'name': _0x1576d5.confirmYes.openTime,
      'value': new Date(_0x3fa5dd.channel.createdTimestamp).toLocaleString(),
      'inline': true
    }, {
      'name': _0x1576d5.confirmYes.closeTime,
      'value': new Date().toLocaleString(),
      'inline': true
    });
    const _0x51a8a4 = await _0x3fa5dd.guild.members.fetch(_0x3fa5dd.channel.topic)["catch"](() => {});
    if (_0x51a8a4) {
      const _0x9b4300 = await _0x51a8a4.send({
        'embeds': [_0x4e8411],
        'files': [{
          'name': "ticket.html",
          'attachment': Buffer.from(_0x227251)
        }]
      })["catch"](() => {});
      if (!_0x9b4300) {
        return;
      }
      const _0x577f69 = new ButtonBuilder().setURL(Array.from(_0x9b4300.attachments)[0][1].url).setLabel(_0x1576d5.confirmYes.download).setStyle(ButtonStyle.Link);
      const _0xa84f38 = new ActionRowBuilder().addComponents(_0x577f69);
      const _0x153493 = new EmbedBuilder(_0x9b4300.embeds[0]).setThumbnail("attachment://ticket.html", true);
      _0x9b4300.edit({
        'components': [_0xa84f38],
        'embeds': [_0x153493]
      });
    }
  }
};
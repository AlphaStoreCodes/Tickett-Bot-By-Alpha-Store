module.exports = {
  'name': "select",
  async 'execute'(_0x4ec41c, _0x26b79e) {
    const _0x49fbb5 = _0x4ec41c.locale.get(_0x4ec41c.config.language);
    await _0x26b79e.deferReply({
      'ephemeral': true
    })["catch"](() => {});
    const _0x3513b9 = _0x26b79e.isAnySelectMenu() ? _0x26b79e.values[0] : _0x26b79e.customId.split('*')[1];
    if (_0x4ec41c.config.optionConfig[_0x3513b9]) {
      const {
        roleId: _0x58e61b,
        image: _0x22d307,
        categoryID: _0x353755
      } = _0x4ec41c.config.optionConfig[_0x3513b9];
      const _0x41bd87 = _0x353755 ? _0x353755 : _0x4ec41c.config.categoryID;
      const _0x2d5fc6 = _0x26b79e.guild.channels.cache.get(_0x41bd87);
      if (!_0x2d5fc6 || _0x2d5fc6.type !== ChannelType.GuildCategory) {
        return;
      }
      const _0x554c62 = await _0x2d5fc6.children.cache.find(_0x3108ba => _0x3108ba.topic == _0x26b79e.user.id);
      if (_0x554c62) {
        _0x26b79e.editReply({
          'content': _0x49fbb5.select.alreadyCreated,
          'ephemeral': true
        });
        return;
      }
      const _0x288ecf = (await _0x4ec41c.db.get("tickets")) || 0;
      const _0x28b15c = await _0x26b79e.guild.channels.create({
        'name': "🎫・" + (_0x288ecf + 1),
        'type': ChannelType.GuildText,
        'topic': _0x26b79e.user.id,
        'parent': _0x2d5fc6.id,
        'permissionOverwrites': [{
          'id': _0x26b79e.guild.id,
          'deny': [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages]
        }, {
          'id': _0x26b79e.user.id,
          'allow': [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages]
        }, {
          'id': _0x58e61b,
          'allow': [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages]
        }, {
          'id': _0x4ec41c.user.id,
          'allow': [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages]
        }]
      });
      await _0x4ec41c.db.set("tickets", _0x288ecf + 1);
      await _0x4ec41c.db.set("ticket-" + _0x26b79e.guild.id + '-' + _0x26b79e.user.id, {
        'id': _0x288ecf + 1,
        'channel': _0x28b15c,
        'selectedOption': _0x3513b9
      });
      const _0x2dff4f = _0x26b79e.user;
      const _0x2d6a66 = "<@&" + _0x58e61b + '>';
      const _0x540757 = new AttachmentBuilder(_0x22d307, {
        'name': "image.png"
      });
      const _0x226fb4 = await _0x28b15c.send({
        'content': _0x49fbb5.select.helloUser.replace("[user]", _0x2dff4f).replace("[role]", _0x2d6a66),
        'files': [_0x540757]
      });
      const _0x33ff48 = new ButtonBuilder().setCustomId("claim").setLabel(_0x49fbb5.select.claim).setStyle(ButtonStyle.Secondary);
      const _0x3f6e62 = new ButtonBuilder().setCustomId("close").setLabel(_0x49fbb5.select.close).setStyle(ButtonStyle.Secondary);
      const _0x23ba2c = new ButtonBuilder().setCustomId("rename").setLabel(_0x49fbb5.select.rename).setStyle(ButtonStyle.Secondary);
      const _0x13dfc7 = new ActionRowBuilder().addComponents(_0x33ff48, _0x3f6e62, _0x23ba2c);
      await _0x226fb4.edit({
        'components': [_0x13dfc7]
      });
      await _0x26b79e.editReply({
        'content': _0x49fbb5.select.created.replace("[channel]", _0x28b15c),
        'ephemeral': true
      })["catch"](() => {});
    }
  }
};
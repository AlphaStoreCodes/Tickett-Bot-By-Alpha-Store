const fs = require('fs');
module.exports = {
  'name': "deleteSection",
  async 'execute'(_0x566587, _0x54acb6) {
    const _0x2c7540 = _0x566587.locale.get(_0x566587.config.language);
    await _0x54acb6.deferReply({
      'ephemeral': true
    })["catch"](() => {});
    const _0x2eb703 = _0x54acb6.values[0];
    delete _0x566587.config.optionConfig[_0x2eb703];
    _0x566587.config.ticketOptions = _0x566587.config.ticketOptions.filter(_0x473718 => _0x473718.value !== _0x2eb703);
    fs.writeFileSync("config.json", JSON.stringify(_0x566587.config, null, 2));
    _0x54acb6.editReply({
      'content': _0x2c7540.deleteSection.success,
      'ephemeral': true
    });
  }
};
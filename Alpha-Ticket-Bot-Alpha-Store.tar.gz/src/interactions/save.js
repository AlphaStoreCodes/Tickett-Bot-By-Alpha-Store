module.exports = {
  'name': "save",
  async 'execute'(_0x4f7d4f, _0x501a7e) {
    const _0x35cec4 = _0x4f7d4f.locale.get(_0x4f7d4f.config.language);
    await _0x501a7e.deferUpdate();
    const _0x2c5a58 = await _0x4f7d4f.db.get("ticket-" + _0x501a7e.guild.id + '-' + _0x501a7e.channel.topic);
    const _0x199316 = new EmbedBuilder().setTitle(_0x35cec4.save.ticketClosed).setColor("#05131f").addFields({
      'name': _0x35cec4.save.openedBy,
      'value': '<@' + _0x501a7e.channel.topic + '>',
      'inline': true
    }, {
      'name': _0x35cec4.save.claimedBy,
      'value': _0x2c5a58?.["claimed"] ? '<@' + _0x2c5a58.claimed + '>' : _0x35cec4.save.noOne,
      'inline': true
    }, {
      'name': _0x35cec4.save.closedBy,
      'value': '<@' + _0x2c5a58?.["closedBy"] + '>',
      'inline': true
    }, {
      'name': _0x35cec4.save.openTime,
      'value': new Date(_0x501a7e.channel.createdTimestamp).toLocaleString(),
      'inline': true
    }, {
      'name': _0x35cec4.save.closeTime,
      'value': new Date().toLocaleString(),
      'inline': true
    });
    const _0x41a82a = await generateHtmlPage(_0x501a7e.channel);
    const _0x3e5a23 = await _0x501a7e.guild.channels.cache.get(_0x4f7d4f.config.log);
    if (_0x3e5a23) {
      const _0x328c67 = await _0x3e5a23.send({
        'embeds': [_0x199316],
        'files': [{
          'name': "ticket.html",
          'attachment': Buffer.from(_0x41a82a)
        }]
      });
      const _0x46c7af = new ButtonBuilder().setURL(Array.from(_0x328c67.attachments)[0][1].url).setLabel(_0x35cec4.save.download).setStyle(ButtonStyle.Link);
      const _0x8cbb57 = new ActionRowBuilder().addComponents(_0x46c7af);
      const _0x1f5ff8 = new EmbedBuilder(_0x328c67.embeds[0]).setThumbnail("attachment://ticket.html");
      _0x328c67.edit({
        'components': [_0x8cbb57],
        'embeds': [_0x1f5ff8]
      });
    }
    _0x501a7e.message.components[0].components[0].data.disabled = true;
    _0x501a7e.editReply({
      'components': _0x501a7e.message.components
    });
  }
};
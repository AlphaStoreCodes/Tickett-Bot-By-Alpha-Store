const {
  ActionRowBuilder,
  PermissionFlagsBits,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle
} = require("discord.js");
module.exports = {
  'name': "rename",
  async 'execute'(_0x181f1c, _0x34e79f) {
    const _0x59c48e = _0x181f1c.locale.get(_0x181f1c.config.language);
    if (_0x34e79f.isModalSubmit()) {
      const _0x4450a7 = _0x34e79f.fields.getTextInputValue("name");
      if (!_0x34e79f.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
        _0x34e79f.reply({
          'content': _0x59c48e.rename.missingPermissions,
          'ephemeral': true
        });
        return;
      }
      _0x34e79f.channel.setName(_0x4450a7);
      _0x34e79f.reply({
        'content': _0x59c48e.rename.nameChanged,
        'ephemeral': true
      });
    } else {
      const _0x445b80 = new ModalBuilder().setCustomId("rename").setTitle(_0x59c48e.rename.modalTitle).addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId("name").setMaxLength(40).setMinLength(2).setLabel(_0x59c48e.rename.modalLabel).setStyle(TextInputStyle.Short).setRequired(true)));
      await _0x34e79f.showModal(_0x445b80);
    }
  }
};
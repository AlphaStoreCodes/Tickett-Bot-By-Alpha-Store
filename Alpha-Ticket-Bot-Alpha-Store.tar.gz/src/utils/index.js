const discordTranscripts = require("discord-html-transcripts");
const {
  Client,
  Collection,
  GatewayIntentBits
} = require("discord.js");
const {
  QuickDB
} = require("quick.db");
const generateHtmlPage = async _0x52cf3d => {
  const _0x50bbff = await discordTranscripts.createTranscript(_0x52cf3d, {
    'limit': -1,
    'returnType': "string",
    'filename': "transcript.html",
    'saveImages': true,
    'poweredBy': false,
    'ssr': false
  });
  return _0x50bbff;
};
class CustomClient extends Client {
  constructor() {
    super({
      'intents': [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages]
    });
    this.locale = new Collection();
    this.commands = new Collection();
    this.interactions = new Collection();
    this.db = new QuickDB({
      'filePath': "./database/tickets.sqlite"
    });
    this.config = require("../../config.json");
  }
}
module.exports = {
  'generateHtmlPage': generateHtmlPage,
  'CustomClient': CustomClient
};
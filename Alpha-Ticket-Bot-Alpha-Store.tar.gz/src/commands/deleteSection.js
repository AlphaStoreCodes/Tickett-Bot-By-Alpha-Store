const {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  SlashCommandBuilder,
  PermissionFlagsBits
} = require("discord.js");
const Locale = require("../locale/en.json");
module.exports = {
  'name': "delete_section",
  'data': new SlashCommandBuilder().setName("delete_section").setDescription(Locale.deleteSection.Description).setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async 'execute'(_0x827156, _0x3a4aeb) {
    const _0x5695f7 = _0x827156.locale.get(_0x827156.config.language);
    await _0x3a4aeb.deferReply({
      'ephemeral': true
    });
    const _0x510d1b = new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId("deleteSection").setPlaceholder(_0x5695f7.deleteSection.SelectPlaceholder).addOptions(_0x827156.config.ticketOptions));
    _0x3a4aeb.editReply({
      'content': _0x5695f7.deleteSection.deleteMessage,
      'ephemeral': true,
      'components': [_0x510d1b]
    });
  }
};
const {
  StringSelectMenuBuilder,
  AttachmentBuilder,
  PermissionFlagsBits,
  SlashCommandBuilder,
  ButtonBuilder,
  ActionRowBuilder
} = require("discord.js");
const Locale = require("../locale/en.json");
module.exports = {
  'name': "setup",
  'data': new SlashCommandBuilder().setName("setup").setDescription(Locale.setup.Description).setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async 'execute'(_0x4337bb, _0x1134c6) {
    const _0xe312f5 = _0x4337bb.locale.get(_0x4337bb.config.language);
    await _0x1134c6.deferReply({
      'ephemeral': true
    });
    const _0x3bc33d = new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId("select").setPlaceholder(_0xe312f5.setup.SelectPlaceholder).addOptions(_0x4337bb.config.ticketOptions));
    const _0x36c697 = [];
    for (const _0x2cc807 of _0x4337bb.config.ticketOptions) {
      const _0x27652f = new ButtonBuilder().setCustomId("select*" + _0x2cc807.value).setLabel(_0x2cc807.label).setStyle("Secondary");
      if (_0x2cc807.emoji) {
        _0x27652f.setEmoji(_0x2cc807.emoji);
      }
      _0x36c697.push(_0x27652f);
    }
    const _0x316b12 = [];
    for (let _0x5abe4b = 0; _0x5abe4b < _0x36c697.length; _0x5abe4b += 5) {
      _0x316b12.push(new ActionRowBuilder().addComponents(_0x36c697.slice(_0x5abe4b, _0x5abe4b + 5)));
    }
    if (!_0x4337bb.config.BACKGROUND) {
      _0x1134c6.editReply({
        'content': "You need to set up the ticket background first before proceeding.",
        'ephemeral': true
      });
    }
    const _0x2119ab = new AttachmentBuilder(_0x4337bb.config.BACKGROUND, {
      'name': "BACKGROUND.png"
    });
    const _0x5ce07e = _0x4337bb.config.SECTION_TYPE === "list" ? [_0x3bc33d] : _0x316b12;
    const _0x5b783f = {
      'files': [_0x2119ab],
      'components': _0x5ce07e.length ? _0x5ce07e : []
    };
    await _0x1134c6.channel.send(_0x5b783f);
    if (_0x4337bb.config.LINE) {
      const _0x1d10e3 = new AttachmentBuilder(_0x4337bb.config.LINE, {
        'name': "LINE.png"
      });
      await _0x1134c6.channel.send({
        'files': [_0x1d10e3]
      });
    }
    _0x1134c6.editReply({
      'content': _0xe312f5.setup.success,
      'ephemeral': true
    });
  }
};
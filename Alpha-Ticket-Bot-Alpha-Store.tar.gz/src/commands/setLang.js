const {
  PermissionFlagsBits,
  SlashCommandBuilder
} = require("discord.js");
const fs = require('fs');
module.exports = {
  'name': "setlang",
  'data': new SlashCommandBuilder().setName("setlang").setDescription("Set the language for the bot").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild).addStringOption(_0xaaa921 => _0xaaa921.setName("language").setDescription("The language to set").addChoices({
    'name': "English",
    'value': 'en'
  }, {
    'name': "Arabic",
    'value': 'ar'
  }).setRequired(true)),
  async 'execute'(_0x392ba0, _0x3f27a1) {
    const _0x3d0bdd = _0x3f27a1.options.getString("language");
    _0x392ba0.config.language = _0x3d0bdd;
    fs.writeFileSync("config.json", JSON.stringify(_0x392ba0.config, null, 2));
    const _0x2dd1b3 = _0x392ba0.locale.get(_0x3d0bdd);
    _0x3f27a1.reply({
      'content': _0x2dd1b3.setLang.success,
      'ephemeral': true
    });
  }
};
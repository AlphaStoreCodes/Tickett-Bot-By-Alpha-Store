const Locale = require("../locale/en.json");
const {
  PermissionFlagsBits,
  SlashCommandBuilder
} = require("discord.js");
const fs = require('fs');
module.exports = {
  'name': "add_section",
  'data': new SlashCommandBuilder().setName("add_section").setDescription(Locale.addSection.Description).setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild).addStringOption(_0x22e4ab => _0x22e4ab.setName("section").setDescription(Locale.addSection.SectionNameDescription).setRequired(true)).addRoleOption(_0x5d3535 => _0x5d3535.setName("role").setDescription(Locale.addSection.RoleDescription).setRequired(true)).addAttachmentOption(_0x2cdd23 => _0x2cdd23.setName("image").setDescription(Locale.addSection.imageDescription).setRequired(true)).addStringOption(_0x1c7603 => _0x1c7603.setName("emoji").setDescription(Locale.addSection.emoji)),
  async 'execute'(_0x52fd20, _0x3f53db) {
    const _0x5dde95 = _0x52fd20.locale.get(_0x52fd20.config.language);
    await _0x3f53db.deferReply({
      'ephemeral': true
    })["catch"](() => {});
    const _0x592b9c = _0x3f53db.options.get("section");
    const _0x5d29e0 = _0x3f53db.options.get("role");
    const _0x5b3e45 = _0x3f53db.options.get("image");
    const _0x3175cc = _0x3f53db.options.get("emoji");
    if (_0x3175cc) {
      if (!/(?::\w+:|<:[^:\s]+:\d+>|[\uD83C-\uDBFF\uDC00-\uDFFF\uD83D\uDC00-\uDE4F\uD83D\uDE80-\uDEF3])/.test(_0x3175cc.value.trim())) {
        _0x3f53db.editReply({
          'content': _0x5dde95.addSection.emojiError,
          'ephemeral': true
        });
        return;
      }
    }
    if (_0x52fd20.config.optionConfig[_0x592b9c.value]) {
      _0x3f53db.editReply({
        'content': _0x5dde95.addSection.error,
        'ephemeral': true
      });
      return;
    }
    _0x52fd20.config.optionConfig[_0x592b9c.value] = {
      'roleId': _0x5d29e0.role.id,
      'image': _0x5b3e45.attachment.url
    };
    _0x52fd20.config.ticketOptions.push(_0x3175cc ? {
      'label': _0x592b9c.value,
      'value': _0x592b9c.value,
      'emoji': _0x3175cc.value.trim()
    } : {
      'label': _0x592b9c.value,
      'value': _0x592b9c.value
    });
    fs.writeFileSync("config.json", JSON.stringify(_0x52fd20.config, null, 2), () => {});
    _0x3f53db.editReply({
      'content': _0x5dde95.addSection.success,
      'ephemeral': true
    });
  }
};
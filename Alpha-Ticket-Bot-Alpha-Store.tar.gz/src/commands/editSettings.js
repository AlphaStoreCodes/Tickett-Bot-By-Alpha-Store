const {
  PermissionFlagsBits,
  SlashCommandBuilder,
  ChannelType
} = require("discord.js");
const fs = require('fs');
const Locale = require("../locale/en.json");
module.exports = {
  'name': "edit_settings",
  'data': new SlashCommandBuilder().setName("edit_settings").setDescription(Locale.editSettings.Description).setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild).addChannelOption(_0x5c7e0f => _0x5c7e0f.setName("category").addChannelTypes(ChannelType.GuildCategory).setDescription(Locale.editSettings.category)).addChannelOption(_0x3d9915 => _0x3d9915.setName("logs").addChannelTypes(ChannelType.GuildText).setDescription(Locale.editSettings.logs)).addAttachmentOption(_0x2762d7 => _0x2762d7.setName("background").setDescription(Locale.editSettings.BACKGROUND)).addAttachmentOption(_0x180e4a => _0x180e4a.setName("line").setDescription(Locale.editSettings.LINE)).addStringOption(_0xd2efac => _0xd2efac.setName("section_type").setDescription(Locale.editSettings.SECTION_TYPE).addChoices({
    'name': "Buttons",
    'value': "buttons"
  }, {
    'name': "List",
    'value': "list"
  })),
  async 'execute'(_0xd17055, _0x29e5b6) {
    const _0xd4062 = _0xd17055.locale.get(_0xd17055.config.language);
    await _0x29e5b6.deferReply({
      'ephemeral': true
    })["catch"](() => {});
    const _0x36c8a3 = _0x29e5b6.options.getChannel("category");
    const _0x2170ab = _0x29e5b6.options.getChannel("logs");
    const _0x3e9916 = _0x29e5b6.options.getAttachment("background");
    const _0x55eb6a = _0x29e5b6.options.getAttachment("line");
    const _0x1a34c4 = _0x29e5b6.options.getString("section_type");
    if (_0x36c8a3 && _0x36c8a3.type !== ChannelType.GuildCategory) {
      _0x29e5b6.editReply({
        'content': _0xd4062.editSettings.error,
        'ephemeral': true
      });
      return;
    }
    if (_0x2170ab && _0x2170ab.type !== ChannelType.GuildText) {
      _0x29e5b6.editReply({
        'content': _0xd4062.editSettings.error,
        'ephemeral': true
      });
      return;
    }
    if (_0x36c8a3) {
      _0xd17055.config.categoryID = _0x36c8a3.id;
    }
    if (_0x2170ab) {
      _0xd17055.config.log = _0x2170ab.id;
    }
    if (_0x3e9916) {
      _0xd17055.config.BACKGROUND = _0x3e9916.url;
    }
    if (_0x55eb6a) {
      _0xd17055.config.LINE = _0x55eb6a.url;
    }
    if (_0x1a34c4) {
      _0xd17055.config.SECTION_TYPE = _0x1a34c4;
    }
    fs.writeFileSync("config.json", JSON.stringify(_0xd17055.config, null, 2));
    _0x29e5b6.editReply({
      'content': _0xd4062.editSettings.success,
      'ephemeral': true
    });
  }
};